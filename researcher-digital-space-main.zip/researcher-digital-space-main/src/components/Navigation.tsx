import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

const navigationItems = [
  { name: "Home", path: "/" },
  { name: "Bio", path: "/bio" },
  { name: "Publications", path: "/publications" },
  { name: "Research & Projects", path: "/research" },
  { name: "Blog", path: "/blog" },
];

export const Navigation = () => {
  const location = useLocation();

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-center">
          <div className="flex space-x-8 overflow-x-auto py-4">
            {navigationItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "px-3 py-2 text-sm font-medium transition-colors duration-200 whitespace-nowrap",
                  "hover:text-academic-blue",
                  location.pathname === item.path
                    ? "text-academic-blue border-b-2 border-academic-blue"
                    : "text-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};