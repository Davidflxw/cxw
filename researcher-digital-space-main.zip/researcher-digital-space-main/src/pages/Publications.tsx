import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Play, ExternalLink, Award } from "lucide-react";

const Publications = () => {
  const publicationsByYear = {
    "2025": [
      {
        title: "Democratizing AI: A Framework for Inclusive Design in Machine Learning Systems",
        authors: "Sarah Chen, Michael Rodriguez, Jennifer Kim, David Thompson",
        venue: "Nature Machine Intelligence",
        type: "Journal",
        special: "Cover Article",
        links: {
          pdf: "/papers/chen2025-democratizing.pdf",
          bibtex: "/bibtex/chen2025-democratizing.bib",
          video: "https://youtube.com/watch?v=example"
        }
      },
      {
        title: "Adaptive Explanations: Personalizing AI Decision-Making for Diverse Users",
        authors: "Jennifer Kim, Sarah Chen, Alex Martinez",
        venue: "CHI '25: Proceedings of the 2025 CHI Conference on Human Factors in Computing Systems",
        type: "Conference",
        special: "Best Paper Honorable Mention",
        links: {
          pdf: "/papers/kim2025-adaptive.pdf",
          bibtex: "/bibtex/kim2025-adaptive.bib"
        }
      }
    ],
    "2024": [
      {
        title: "Inclusive AI: Designing for Diverse Mental Models in Human-Computer Interaction",
        authors: "Sarah Chen, David Thompson, Lisa Wang, Robert Johnson",
        venue: "CHI '24: Proceedings of the 2024 CHI Conference on Human Factors in Computing Systems",
        type: "Conference",
        special: "Best Paper Award",
        links: {
          pdf: "/papers/chen2024-inclusive.pdf",
          bibtex: "/bibtex/chen2024-inclusive.bib",
          video: "https://youtube.com/watch?v=example"
        }
      },
      {
        title: "Bridging the Gap: Cultural Considerations in AI Interface Design",
        authors: "Michael Rodriguez, Sarah Chen, Emily Zhou",
        venue: "ACM Transactions on Computer-Human Interaction",
        type: "Journal",
        links: {
          pdf: "/papers/rodriguez2024-bridging.pdf",
          bibtex: "/bibtex/rodriguez2024-bridging.bib"
        }
      },
      {
        title: "Mental Model Elicitation Techniques for AI System Design",
        authors: "Sarah Chen, Jennifer Kim",
        venue: "International Journal of Human-Computer Studies",
        type: "Journal",
        links: {
          pdf: "/papers/chen2024-mental.pdf",
          bibtex: "/bibtex/chen2024-mental.bib"
        }
      }
    ],
    "2023": [
      {
        title: "Adaptive Interfaces for Cognitive Accessibility in AI Systems",
        authors: "David Thompson, Sarah Chen, Alex Martinez, Lisa Wang",
        venue: "UIST '23: Proceedings of the 36th Annual ACM Symposium on User Interface Software and Technology",
        type: "Conference",
        special: "Best Paper Award",
        links: {
          pdf: "/papers/thompson2023-adaptive.pdf",
          bibtex: "/bibtex/thompson2023-adaptive.bib",
          video: "https://youtube.com/watch?v=example"
        }
      },
      {
        title: "Cross-Cultural Design Patterns in AI-Powered Applications",
        authors: "Emily Zhou, Sarah Chen, Michael Rodriguez",
        venue: "Design Studies",
        type: "Journal",
        links: {
          pdf: "/papers/zhou2023-cross.pdf",
          bibtex: "/bibtex/zhou2023-cross.bib"
        }
      }
    ],
    "2022": [
      {
        title: "Mental Model Mapping in Human-AI Interaction: A Cognitive Framework",
        authors: "Sarah Chen, Robert Johnson, Jennifer Kim",
        venue: "IUI '22: Proceedings of the 27th International Conference on Intelligent User Interfaces",
        type: "Conference",
        special: "Best Paper Award",
        links: {
          pdf: "/papers/chen2022-mental.pdf",
          bibtex: "/bibtex/chen2022-mental.bib"
        }
      },
      {
        title: "Participatory Design Methods for Inclusive AI Development",
        authors: "Lisa Wang, Sarah Chen, David Thompson",
        venue: "ACM Computing Surveys",
        type: "Journal",
        links: {
          pdf: "/papers/wang2022-participatory.pdf",
          bibtex: "/bibtex/wang2022-participatory.bib"
        }
      }
    ],
    "2021": [
      {
        title: "AI Accessibility: Bridging the Digital Divide Through Inclusive Design",
        authors: "Sarah Chen, Alex Martinez, Emily Zhou, Michael Rodriguez",
        venue: "CHI '21: Proceedings of the 2021 CHI Conference on Human Factors in Computing Systems",
        type: "Conference",
        special: "Best Paper Award",
        links: {
          pdf: "/papers/chen2021-accessibility.pdf",
          bibtex: "/bibtex/chen2021-accessibility.bib",
          video: "https://youtube.com/watch?v=example"
        }
      }
    ]
  };

  const getSpecialBadge = (special: string) => {
    if (special.includes("Best Paper Award")) {
      return <Badge variant="destructive" className="ml-2"><Award className="h-3 w-3 mr-1" />Best Paper</Badge>;
    }
    if (special.includes("Honorable Mention")) {
      return <Badge variant="secondary" className="ml-2"><Award className="h-3 w-3 mr-1" />Honorable Mention</Badge>;
    }
    if (special.includes("Cover Article")) {
      return <Badge variant="default" className="ml-2">Cover Article</Badge>;
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-foreground mb-8 text-center">Publications</h1>
        
        <div className="space-y-12">
          {Object.entries(publicationsByYear).map(([year, papers]) => (
            <div key={year}>
              <h2 className="text-2xl font-bold text-academic-blue mb-6 border-b border-border pb-2">
                {year}
              </h2>
              
              <div className="space-y-6">
                {papers.map((paper, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground mb-2 leading-tight">
                            {paper.title}
                            {paper.special && getSpecialBadge(paper.special)}
                          </h3>
                          <p className="text-muted-foreground mb-2">{paper.authors}</p>
                          <p className="text-academic-blue font-medium">{paper.venue}</p>
                        </div>
                        <Badge variant="outline" className="ml-4">
                          {paper.type}
                        </Badge>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm">
                          <FileText className="h-4 w-4 mr-2" />
                          PDF
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          BibTeX
                        </Button>
                        {paper.links.video && (
                          <Button variant="outline" size="sm">
                            <Play className="h-4 w-4 mr-2" />
                            Video
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Publisher
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default Publications;