import { Download, ExternalLink, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const Landing = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="mb-6 flex items-center justify-center gap-8">
            {/* Profile Photo Upload */}
            <div className="w-32 h-32 border-2 border-dashed border-academic-blue rounded-lg flex items-center justify-center bg-academic-accent/10 hover:bg-academic-accent/20 transition-colors cursor-pointer">
              <div className="text-center">
                <div className="text-academic-blue text-sm font-medium">Upload Photo</div>
                <div className="text-muted-foreground text-xs mt-1">Square format</div>
              </div>
            </div>
            
            <div>
              <h1 className="text-5xl font-bold text-foreground mb-4">
                Dr. Sarah Chen
              </h1>
            <p className="text-lg text-text-subtle mb-2">
              Pronounced: <span className="italic">/ˈsɛrə ˈtʃɛn/ (SAIR-uh CHEN)</span>
            </p>
            <p className="text-xl text-muted-foreground">
              She/Her/Hers
            </p>
            </div>
          </div>
          
          <div className="text-center mb-8">
            <h2 className="text-2xl font-semibold text-academic-blue mb-3">
              Assistant Professor of Computer Science
            </h2>
            <p className="text-lg text-muted-foreground">
              Stanford University • Artificial Intelligence Laboratory
            </p>
          </div>

          <p className="text-lg text-foreground max-w-3xl mx-auto leading-relaxed">
            Welcome! I'm a researcher focused on human-AI interaction, computational creativity, 
            and inclusive technology design. My work bridges computer science, cognitive psychology, 
            and design to create AI systems that amplify human potential.
          </p>
        </div>


        {/* Recent Highlights */}
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-foreground mb-6">Recent Highlights</h2>
          <div className="space-y-4 text-left max-w-2xl mx-auto">
            <div className="border-l-4 border-academic-accent pl-4">
              <p className="font-medium">🏆 NSF CAREER Award (2024)</p>
              <p className="text-muted-foreground text-sm">
                For research on "Democratizing AI Through Human-Centered Design"
              </p>
            </div>
            <div className="border-l-4 border-academic-accent pl-4">
              <p className="font-medium">📚 Best Paper Award at CHI 2024</p>
              <p className="text-muted-foreground text-sm">
                "Inclusive AI: Designing for Diverse Mental Models"
              </p>
            </div>
            <div className="border-l-4 border-academic-accent pl-4">
              <p className="font-medium">🎙️ Featured on MIT Technology Review Podcast</p>
              <p className="text-muted-foreground text-sm">
                Discussing the future of human-AI collaboration
              </p>
            </div>
          </div>
        </div>

        {/* Contact Links */}
        <div className="text-center mt-16 pt-8 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground mb-6">Connect</h3>
          <div className="flex justify-center items-center gap-6 flex-wrap">
            <Button variant="outline" size="sm">
              <ExternalLink className="mr-2 h-4 w-4" />
              LinkedIn
            </Button>
            <Button variant="outline" size="sm">
              <ExternalLink className="mr-2 h-4 w-4" />
              ORCID
            </Button>
            <Button variant="outline" size="sm">
              <ExternalLink className="mr-2 h-4 w-4" />
              Google Scholar
            </Button>
            <div className="text-academic-blue font-medium">
              sarah.chen@stanford.edu
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;