import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Users, Lightbulb, Globe, Accessibility, Zap } from "lucide-react";

const Research = () => {
  const researchThemes = [
    {
      icon: Brain,
      title: "Human-AI Interaction",
      description: "Designing AI systems that complement human cognition and decision-making processes",
      motivation: "How can we create AI that truly understands and adapts to diverse human mental models?",
      projects: ["Adaptive Explanation Systems", "Mental Model Mapping", "Cognitive Load Assessment"],
      collaborations: ["MIT CSAIL", "Google Research", "Microsoft Research"]
    },
    {
      icon: Accessibility,
      title: "Inclusive Technology Design",
      description: "Creating accessible AI systems that work for users across different abilities and backgrounds",
      motivation: "Technology should empower everyone, regardless of their cognitive, physical, or cultural differences",
      projects: ["Accessible AI Interfaces", "Cultural Adaptation Frameworks", "Disability-Inclusive Design"],
      collaborations: ["WHO", "AccessibilityFirst Consortium", "Inclusive Design Research Centre"]
    },
    {
      icon: Lightbulb,
      title: "Computational Creativity",
      description: "Exploring how AI can augment human creativity while preserving human agency",
      motivation: "Can AI become a true creative partner that enhances rather than replaces human imagination?",
      projects: ["Creative AI Assistants", "Collaborative Design Tools", "AI-Human Co-creation"],
      collaborations: ["Adobe Research", "Autodesk AI Lab", "MIT Media Lab"]
    },
    {
      icon: Globe,
      title: "Cross-Cultural AI",
      description: "Developing AI systems that understand and respect cultural diversity",
      motivation: "AI should reflect the rich diversity of human cultures and communication styles",
      projects: ["Cultural Bias Detection", "Multilingual Interface Design", "Global User Studies"],
      collaborations: ["UNESCO", "International Research Universities", "Cultural Heritage Organizations"]
    }
  ];

  const labOverview = {
    mission: "To create AI systems that are not just technically sophisticated, but truly human-centered, inclusive, and beneficial for all members of society.",
    approach: "We combine rigorous computational research with deep human insights, using interdisciplinary methods from computer science, psychology, design, and anthropology.",
    impact: "Our work has influenced AI product design at major technology companies and informed policy discussions on ethical AI development."
  };

  const currentProjects = [
    {
      title: "NSF CAREER: Democratizing AI Through Human-Centered Design",
      period: "2024-2029",
      funding: "$500,000",
      description: "Developing frameworks and tools that make AI development more accessible to diverse communities"
    },
    {
      title: "Inclusive AI Design Patterns",
      period: "2023-2026",
      funding: "$2,000,000",
      description: "Multi-university collaboration to establish design patterns for accessible AI systems"
    },
    {
      title: "Cultural Adaptation in AI Interfaces",
      period: "2024-2027",
      funding: "$750,000",
      description: "Understanding how cultural background influences interaction with AI systems"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-foreground mb-8 text-center">
          Research & Projects
        </h1>

        {/* Lab Overview */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-academic-blue" />
              Human-AI Interaction Lab
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-academic-blue mb-2">Our Mission</h4>
                <p className="text-foreground leading-relaxed">{labOverview.mission}</p>
              </div>
              <div>
                <h4 className="font-semibold text-academic-blue mb-2">Our Approach</h4>
                <p className="text-foreground leading-relaxed">{labOverview.approach}</p>
              </div>
              <div>
                <h4 className="font-semibold text-academic-blue mb-2">Our Impact</h4>
                <p className="text-foreground leading-relaxed">{labOverview.impact}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Research Themes */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-academic-blue mb-8 text-center">
            Research Themes
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {researchThemes.map((theme, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <theme.icon className="h-6 w-6 text-academic-blue" />
                    {theme.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground mb-4 leading-relaxed">{theme.description}</p>
                  
                  <div className="mb-4">
                    <h5 className="font-semibold text-academic-blue mb-2">Motivation</h5>
                    <p className="text-muted-foreground italic text-sm">{theme.motivation}</p>
                  </div>

                  <div className="mb-4">
                    <h5 className="font-semibold text-academic-blue mb-2">Current Projects</h5>
                    <div className="flex flex-wrap gap-2">
                      {theme.projects.map((project, projIndex) => (
                        <Badge key={projIndex} variant="secondary">
                          {project}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h5 className="font-semibold text-academic-blue mb-2">Key Collaborations</h5>
                    <div className="flex flex-wrap gap-2">
                      {theme.collaborations.map((collab, collabIndex) => (
                        <Badge key={collabIndex} variant="outline">
                          {collab}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Current Major Projects */}
        <div>
          <h2 className="text-2xl font-bold text-academic-blue mb-8 text-center">
            Current Major Projects
          </h2>
          <div className="space-y-6">
            {currentProjects.map((project, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground mb-2">{project.title}</h3>
                      <p className="text-foreground leading-relaxed">{project.description}</p>
                    </div>
                    <div className="ml-6 text-right">
                      <div className="text-academic-blue font-semibold">{project.funding}</div>
                      <div className="text-muted-foreground text-sm">{project.period}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Interdisciplinary Focus */}
        <Card className="mt-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-academic-blue" />
              Interdisciplinary Approach
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed mb-4">
              Our research bridges multiple disciplines to create more holistic solutions. We work 
              at the intersection of computer science, cognitive psychology, design, anthropology, 
              and ethics to ensure our AI systems are not just technically sound, but truly beneficial 
              for diverse human communities.
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <h4 className="font-semibold text-academic-blue mb-2">Technical Excellence</h4>
                <p className="text-sm text-muted-foreground">
                  Rigorous computer science and AI methods
                </p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-academic-blue mb-2">Human Understanding</h4>
                <p className="text-sm text-muted-foreground">
                  Cognitive science and user research insights
                </p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-academic-blue mb-2">Social Impact</h4>
                <p className="text-sm text-muted-foreground">
                  Ethical considerations and inclusive design
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Research;