import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Award, Users, Download, ExternalLink } from "lucide-react";

const Bio = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-foreground mb-8 text-center">Biography</h1>
        
        {/* Academic Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-academic-blue" />
              Academic Background
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-lg max-w-none">
              <p className="text-foreground leading-relaxed mb-4">
                Dr. Sarah Chen is an Assistant Professor of Computer Science at Stanford University, 
                where she leads the Human-AI Interaction Lab. Her research sits at the intersection 
                of artificial intelligence, human-computer interaction, and cognitive science, with 
                a focus on creating more inclusive and accessible AI systems.
              </p>
              
              <p className="text-foreground leading-relaxed mb-4">
                She received her Ph.D. in Computer Science from MIT in 2019, where she was advised 
                by Dr. Regina Barzilay and Dr. Hal Abelson. Her doctoral dissertation, "Bridging 
                Mental Models: Designing AI Systems for Diverse Human Cognition," received the 
                ACM SIGCHI Outstanding Dissertation Award.
              </p>

              <p className="text-foreground leading-relaxed">
                Prior to joining Stanford, Dr. Chen was a postdoctoral researcher at the University 
                of Washington's Center for Human-Computer Interaction, where she developed 
                foundational frameworks for inclusive AI design that are now widely adopted in 
                industry and academia.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Key Achievements */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-academic-blue" />
              Key Recognition & Awards
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-academic-blue mb-2">Major Awards</h4>
                <ul className="space-y-2 text-foreground">
                  <li>• NSF CAREER Award (2024)</li>
                  <li>• ACM SIGCHI Outstanding Dissertation Award (2019)</li>
                  <li>• Google PhD Fellowship (2017-2019)</li>
                  <li>• MIT Presidential Fellowship (2015-2017)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-academic-blue mb-2">Best Paper Awards</h4>
                <ul className="space-y-2 text-foreground">
                  <li>• CHI 2024: "Inclusive AI Design"</li>
                  <li>• UIST 2023: "Adaptive Interfaces"</li>
                  <li>• IUI 2022: "Mental Model Mapping"</li>
                  <li>• CHI 2021: "AI Accessibility"</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Research Impact */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-academic-blue" />
              Research Impact & Community
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-lg max-w-none">
              <p className="text-foreground leading-relaxed mb-4">
                Dr. Chen's work has been recognized for its practical impact on AI system design. 
                Her inclusive design frameworks have been adopted by major technology companies 
                including Google, Microsoft, and Apple, leading to more accessible AI products 
                used by millions of people worldwide.
              </p>
              
              <p className="text-foreground leading-relaxed">
                She serves on the editorial boards of ACM Transactions on Interactive Intelligent 
                Systems and International Journal of Human-Computer Studies. Dr. Chen is also a 
                founding member of the AI for Social Good consortium and regularly consults with 
                policymakers on ethical AI development.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CV Download */}
        <Card>
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-foreground mb-4">Curriculum Vitae</h3>
            <p className="text-muted-foreground mb-4">
              Download my complete academic CV for detailed information about my research, 
              publications, teaching, and service activities.
            </p>
            <Button className="bg-academic-blue hover:bg-academic-blue/90">
              <Download className="mr-2 h-4 w-4" />
              Download Full CV
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Bio;