import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Mic, Video, ExternalLink, Calendar, Clock } from "lucide-react";

const Media = () => {
  const podcasts = [
    {
      title: "The Future of Human-AI Collaboration",
      show: "MIT Technology Review Podcast",
      date: "December 2024",
      duration: "45 mins",
      description: "Deep dive into how AI systems can be designed to truly complement human capabilities",
      link: "https://example.com/podcast1",
      featured: true
    },
    {
      title: "Inclusive Design in the Age of AI",
      show: "Design Better Podcast",
      date: "November 2024",
      duration: "38 mins",
      description: "Discussing practical approaches to making AI accessible for users with diverse needs",
      link: "https://example.com/podcast2"
    },
    {
      title: "Mental Models and Machine Learning",
      show: "AI Ethics Podcast",
      date: "October 2024",
      duration: "52 mins",
      description: "Exploring how understanding human cognition can improve AI system design",
      link: "https://example.com/podcast3"
    },
    {
      title: "Building AI That Works for Everyone",
      show: "The Human-Computer Interaction Podcast",
      date: "September 2024",
      duration: "41 mins",
      description: "Practical strategies for inclusive AI development in academic and industry settings",
      link: "https://example.com/podcast4"
    }
  ];

  const videos = [
    {
      title: "Democratizing AI Through Human-Centered Design",
      venue: "TEDx Stanford",
      date: "November 2024",
      duration: "18 mins",
      description: "How we can make AI development more accessible and inclusive",
      link: "https://youtube.com/watch?v=example1",
      featured: true
    },
    {
      title: "Inclusive AI: Designing for Diverse Mental Models",
      venue: "CHI 2024 Conference Presentation",
      date: "May 2024",
      duration: "25 mins",
      description: "Best Paper Award presentation on inclusive design principles",
      link: "https://youtube.com/watch?v=example2"
    },
    {
      title: "Cross-Cultural Considerations in AI Interface Design",
      venue: "International Conference on AI Ethics",
      date: "September 2024",
      duration: "30 mins",
      description: "Keynote presentation on cultural adaptation in AI systems",
      link: "https://youtube.com/watch?v=example3"
    },
    {
      title: "The Ethics of Human-AI Interaction",
      venue: "Stanford HAI Symposium",
      date: "March 2024",
      duration: "22 mins",
      description: "Panel discussion on ethical considerations in AI design",
      link: "https://youtube.com/watch?v=example4"
    }
  ];

  const profiles = [
    {
      platform: "Stanford HAI",
      title: "Faculty Profile",
      description: "Official faculty profile at Stanford's Human-Centered AI Institute",
      link: "https://hai.stanford.edu/people/sarah-chen"
    },
    {
      platform: "Google Scholar",
      title: "Academic Publications",
      description: "Complete list of publications and citation metrics",
      link: "https://scholar.google.com/citations?user=example"
    },
    {
      platform: "ACM Digital Library",
      title: "Author Profile",
      description: "Publications in ACM conferences and journals",
      link: "https://dl.acm.org/profile/example"
    },
    {
      platform: "IEEE Xplore",
      title: "Research Papers",
      description: "Publications in IEEE conferences and journals",
      link: "https://ieeexplore.ieee.org/author/example"
    }
  ];

  const mediaFeatures = [
    {
      outlet: "MIT Technology Review",
      title: "The Researcher Making AI More Inclusive",
      type: "Feature Article",
      date: "October 2024",
      link: "https://example.com/article1"
    },
    {
      outlet: "Wired Magazine",
      title: "How to Design AI That Actually Helps People",
      type: "Interview",
      date: "August 2024",
      link: "https://example.com/article2"
    },
    {
      outlet: "Stanford News",
      title: "Professor Receives NSF CAREER Award for AI Research",
      type: "News Article",
      date: "March 2024",
      link: "https://example.com/article3"
    },
    {
      outlet: "Nature",
      title: "The Human Side of Artificial Intelligence",
      type: "Commentary",
      date: "June 2024",
      link: "https://example.com/article4"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-foreground mb-12 text-center">
          Media & External Profiles
        </h1>

        {/* Podcasts Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-academic-blue mb-8 flex items-center gap-2">
            <Mic className="h-6 w-6" />
            Podcast Appearances
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {podcasts.map((podcast, index) => (
              <Card key={index} className={`hover:shadow-lg transition-shadow ${podcast.featured ? 'ring-2 ring-academic-accent' : ''}`}>
                <CardContent className="p-6">
                  {podcast.featured && (
                    <Badge className="mb-3 bg-academic-accent text-academic-blue">Featured</Badge>
                  )}
                  <h3 className="font-semibold text-lg text-foreground mb-2">{podcast.title}</h3>
                  <p className="text-academic-blue font-medium mb-2">{podcast.show}</p>
                  <p className="text-muted-foreground text-sm mb-3">{podcast.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-text-subtle">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {podcast.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {podcast.duration}
                      </div>
                    </div>
                  </div>
                  <Button className="w-full" variant="outline">
                    <Play className="h-4 w-4 mr-2" />
                    Listen Now
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Videos Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-academic-blue mb-8 flex items-center gap-2">
            <Video className="h-6 w-6" />
            Video Presentations
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {videos.map((video, index) => (
              <Card key={index} className={`hover:shadow-lg transition-shadow ${video.featured ? 'ring-2 ring-academic-accent' : ''}`}>
                <CardContent className="p-6">
                  {video.featured && (
                    <Badge className="mb-3 bg-academic-accent text-academic-blue">Featured</Badge>
                  )}
                  <h3 className="font-semibold text-lg text-foreground mb-2">{video.title}</h3>
                  <p className="text-academic-blue font-medium mb-2">{video.venue}</p>
                  <p className="text-muted-foreground text-sm mb-3">{video.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-text-subtle">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {video.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {video.duration}
                      </div>
                    </div>
                  </div>
                  <Button className="w-full" variant="outline">
                    <Play className="h-4 w-4 mr-2" />
                    Watch Video
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Media Features */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-academic-blue mb-8">Media Coverage</h2>
          <div className="space-y-4">
            {mediaFeatures.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1">{feature.title}</h3>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-academic-blue font-medium">{feature.outlet}</span>
                        <Badge variant="outline">{feature.type}</Badge>
                        <span className="text-text-subtle">{feature.date}</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Read Article
                      <ExternalLink className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* External Profiles */}
        <div>
          <h2 className="text-2xl font-bold text-academic-blue mb-8">Institutional Profiles</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {profiles.map((profile, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{profile.platform}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{profile.description}</p>
                  <Button variant="outline" className="w-full">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Profile
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Media;